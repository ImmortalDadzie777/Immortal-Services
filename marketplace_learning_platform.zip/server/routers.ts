import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { 
  getProductById, 
  getApprovedProducts, 
  getSellerProducts, 
  getBuyerOrders, 
  getSellerOrders,
  getLearningContentBySubject,
  getUserProgressByContent,
  getProductReviews,
  getUserNotifications,
  getProductsByCategory,
  getLearningContentById,
} from "./db";
import { storagePut } from "./storage";
import { nanoid } from "nanoid";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts: any) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }: any) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  products: router({
    list: publicProcedure
      .input(z.object({ category: z.string().optional(), limit: z.number().default(20) }))
      .query(async ({ input }: any) => {
        if (input.category) return await getProductsByCategory(input.category, input.limit);
        return await getApprovedProducts(input.limit);
      }),
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }: any) => getProductById(input.id)),
    getSellerProducts: protectedProcedure
      .query(async ({ ctx }: any) => getSellerProducts(ctx.user.id)),
  }) as any,

  orders: router({
    getBuyerOrders: protectedProcedure
      .query(async ({ ctx }: any) => getBuyerOrders(ctx.user.id)),
    getSellerOrders: protectedProcedure
      .query(async ({ ctx }: any) => getSellerOrders(ctx.user.id)),
  }) as any,

  learning: router({
    getContentBySubject: publicProcedure
      .input(z.object({ subject: z.string(), difficulty: z.enum(["basic", "intermediate", "advanced"]).optional() }))
      .query(async ({ input }: any) => getLearningContentBySubject(input.subject, input.difficulty)),
    getContentById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }: any) => getLearningContentById(input.id)),
    getUserProgress: protectedProcedure
      .query(async ({ ctx }: any) => getUserProgressByContent(ctx.user.id)),
  }) as any,

  reviews: router({
    getProductReviews: publicProcedure
      .input(z.object({ productId: z.number() }))
      .query(async ({ input }: any) => getProductReviews(input.productId)),
  }) as any,

  notifications: router({
    getUserNotifications: protectedProcedure
      .query(async ({ ctx }: any) => getUserNotifications(ctx.user.id)),
  }) as any,

  chat: router({
    sendMessage: protectedProcedure
      .input(z.object({ message: z.string(), context: z.string().optional() }))
      .mutation(async ({ input }: any) => {
        try {
          const response = await invokeLLM({
            messages: [
              { role: "system", content: "You are a helpful AI assistant for a learning and marketplace platform." },
              { role: "user", content: input.message },
            ] as any,
          });
          return response;
        } catch (error) {
          console.error("Error in chat:", error);
          throw error;
        }
      }) as any,
  }) as any,

  botDeployment: router({
    submitRequest: protectedProcedure
      .input(z.object({ botName: z.string(), description: z.string(), requirements: z.record(z.string(), z.any()).optional() }))
      .mutation(async () => ({
        success: true,
        message: "Bot deployment request submitted successfully",
      })),
  }),
});

export type AppRouter = typeof appRouter;
