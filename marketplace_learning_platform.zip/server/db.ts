import { eq, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, products, orders, learningContent, userProgress, reviews, notifications } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Product queries
 */
export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getProductsByCategory(category: string, limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(products).where(eq(products.category, category)).limit(limit);
}

export async function getApprovedProducts(limit = 20) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(products).where(eq(products.status, "approved")).limit(limit);
}

export async function getSellerProducts(sellerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(products).where(eq(products.sellerId, sellerId));
}

/**
 * Order queries
 */
export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getBuyerOrders(buyerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(orders).where(eq(orders.buyerId, buyerId));
}

export async function getSellerOrders(sellerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(orders).innerJoin(products, eq(orders.productId, products.id)).where(eq(products.sellerId, sellerId));
}

/**
 * Learning content queries
 */
export async function getLearningContentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(learningContent).where(eq(learningContent.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getLearningContentBySubject(subject: string, difficulty?: string) {
  const db = await getDb();
  if (!db) return [];
  if (difficulty) {
    return await db.select().from(learningContent).where(
      and(eq(learningContent.subject, subject), eq(learningContent.difficulty, difficulty as any))
    );
  }
  return await db.select().from(learningContent).where(eq(learningContent.subject, subject));
}

/**
 * User progress queries
 */
export async function getUserProgress(userId: number, contentId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(userProgress).where(
    eq(userProgress.userId, userId) && eq(userProgress.contentId, contentId)
  ).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserProgressByContent(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
}

/**
 * Review queries
 */
export async function getProductReviews(productId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(reviews).where(eq(reviews.productId, productId));
}

/**
 * Notification queries
 */
export async function getUserNotifications(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(notifications).where(eq(notifications.userId, userId));
}
