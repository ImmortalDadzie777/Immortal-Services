CREATE TABLE `quiz_attempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`subject` varchar(100) NOT NULL,
	`difficulty` enum('basic','intermediate','advanced') NOT NULL,
	`question_count` int NOT NULL,
	`correct_answers` int DEFAULT 0,
	`total_score` decimal(5,2) DEFAULT '0.00',
	`max_score` decimal(5,2) NOT NULL,
	`percentage` decimal(5,2) DEFAULT '0.00',
	`time_spent` int,
	`completed_at` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `quiz_attempts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `quiz_attempts` (`user_id`);--> statement-breakpoint
CREATE INDEX `subject_idx` ON `quiz_attempts` (`subject`);