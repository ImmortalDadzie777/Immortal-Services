CREATE TABLE `bot_deployment_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`bot_name` varchar(255) NOT NULL,
	`description` text,
	`requirements` json,
	`status` enum('pending','approved','rejected','deployed') NOT NULL DEFAULT 'pending',
	`deployment_url` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bot_deployment_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `learning_content` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL,
	`subject` varchar(100) NOT NULL,
	`category` varchar(100) NOT NULL,
	`difficulty` enum('basic','intermediate','advanced') NOT NULL DEFAULT 'basic',
	`exam_type` varchar(50),
	`content` text NOT NULL,
	`type` enum('quiz','lesson','practice','question') NOT NULL,
	`created_by` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `learning_content_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text NOT NULL,
	`type` varchar(50) NOT NULL,
	`read` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`buyer_id` int NOT NULL,
	`product_id` int NOT NULL,
	`amount` decimal(10,2) NOT NULL DEFAULT '0.00',
	`currency` varchar(3) NOT NULL DEFAULT 'USD',
	`payment_method` varchar(50) NOT NULL,
	`payment_status` enum('pending','completed','failed','refunded') NOT NULL DEFAULT 'pending',
	`transaction_id` varchar(255),
	`download_token` varchar(255),
	`download_count` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`),
	CONSTRAINT `orders_download_token_unique` UNIQUE(`download_token`)
);
--> statement-breakpoint
CREATE TABLE `products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`seller_id` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`category` varchar(100) NOT NULL,
	`price` decimal(10,2) NOT NULL DEFAULT '0.00',
	`is_free` boolean NOT NULL DEFAULT false,
	`file_url` text NOT NULL,
	`file_key` text NOT NULL,
	`file_type` varchar(50) NOT NULL,
	`file_size_bytes` int,
	`download_limit` int,
	`expires_at` timestamp,
	`rating` decimal(3,2) DEFAULT '0.00',
	`review_count` int DEFAULT 0,
	`download_count` int DEFAULT 0,
	`status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `products_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `referrals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`referrer_id` int NOT NULL,
	`referred_id` int,
	`referral_code` varchar(50) NOT NULL,
	`commission` decimal(10,2) DEFAULT '0.00',
	`status` enum('pending','completed','expired') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`expires_at` timestamp,
	CONSTRAINT `referrals_id` PRIMARY KEY(`id`),
	CONSTRAINT `referrals_referral_code_unique` UNIQUE(`referral_code`)
);
--> statement-breakpoint
CREATE TABLE `reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`product_id` int NOT NULL,
	`user_id` int NOT NULL,
	`rating` int NOT NULL,
	`comment` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reviews_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `user_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`user_id` int NOT NULL,
	`content_id` int NOT NULL,
	`score` decimal(5,2) DEFAULT '0.00',
	`max_score` decimal(5,2) DEFAULT '0.00',
	`streak` int DEFAULT 0,
	`completed` boolean DEFAULT false,
	`completed_at` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_progress_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` enum('user','admin','seller') NOT NULL DEFAULT 'user';--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `bot_deployment_requests` (`user_id`);--> statement-breakpoint
CREATE INDEX `subject_idx` ON `learning_content` (`subject`);--> statement-breakpoint
CREATE INDEX `difficulty_idx` ON `learning_content` (`difficulty`);--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `notifications` (`user_id`);--> statement-breakpoint
CREATE INDEX `buyer_id_idx` ON `orders` (`buyer_id`);--> statement-breakpoint
CREATE INDEX `product_id_idx` ON `orders` (`product_id`);--> statement-breakpoint
CREATE INDEX `seller_id_idx` ON `products` (`seller_id`);--> statement-breakpoint
CREATE INDEX `category_idx` ON `products` (`category`);--> statement-breakpoint
CREATE INDEX `referrer_id_idx` ON `referrals` (`referrer_id`);--> statement-breakpoint
CREATE INDEX `product_id_idx` ON `reviews` (`product_id`);--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `reviews` (`user_id`);--> statement-breakpoint
CREATE INDEX `user_id_idx` ON `user_progress` (`user_id`);--> statement-breakpoint
CREATE INDEX `content_id_idx` ON `user_progress` (`content_id`);