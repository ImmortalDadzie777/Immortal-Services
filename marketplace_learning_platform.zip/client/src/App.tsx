import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Marketplace from "./pages/Marketplace";
import ProductDetail from "./pages/ProductDetail";
import SellerDashboard from "./pages/SellerDashboard";
import BuyerDashboard from "./pages/BuyerDashboard";
import Learning from "./pages/Learning";
import ProductScanner from "./pages/ProductScanner";
import AdminPanel from "./pages/AdminPanel";
import BotDeployment from "./pages/BotDeployment";
import { useAuth } from "./_core/hooks/useAuth";

function Router() {
  const { user, isAuthenticated } = useAuth();

  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/marketplace" component={Marketplace} />
      <Route path="/product/:id" component={ProductDetail} />
      <Route path="/learning" component={Learning} />
      <Route path="/scanner" component={ProductScanner} />
      <Route path="/bot-deployment" component={BotDeployment} />
      
      {/* Protected routes */}
      {isAuthenticated && (
        <>
          <Route path="/seller/dashboard" component={SellerDashboard} />
          <Route path="/buyer/dashboard" component={BuyerDashboard} />
          {user?.role === 'admin' && <Route path="/admin" component={AdminPanel} />}
        </>
      )}
      
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
