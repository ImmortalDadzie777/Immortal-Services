import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { getLoginUrl } from "@/const";
import { Link } from "wouter";
import { ShoppingBag, BookOpen, Camera, Zap, Users, TrendingUp } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-blue-600">MarketLearn</div>
          <div className="flex gap-4">
            {isAuthenticated ? (
              <>
                <Link href="/marketplace">
                  <Button variant="ghost">Marketplace</Button>
                </Link>
                <Link href="/learning">
                  <Button variant="ghost">Learning</Button>
                </Link>
                <Link href="/buyer/dashboard">
                  <Button variant="outline">Dashboard</Button>
                </Link>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button>Sign In</Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Learn, Sell, and Discover with AI
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            A comprehensive platform combining digital product marketplace, AI-powered learning, and smart product discovery
          </p>
          <div className="flex gap-4 justify-center">
            <Link href="/marketplace">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                Browse Marketplace
              </Button>
            </Link>
            <Link href="/learning">
              <Button size="lg" variant="outline">
                Start Learning
              </Button>
            </Link>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-20">
          <Card className="border-0 shadow-lg hover:shadow-xl transition">
            <CardHeader>
              <ShoppingBag className="w-12 h-12 text-blue-600 mb-4" />
              <CardTitle>Digital Marketplace</CardTitle>
              <CardDescription>Buy and sell digital products securely</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Upload PDFs, documents, videos, and more. Secure downloads with expiring links and download limits.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition">
            <CardHeader>
              <BookOpen className="w-12 h-12 text-green-600 mb-4" />
              <CardTitle>AI Learning Platform</CardTitle>
              <CardDescription>Master any subject with AI assistance</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Generate quizzes, solve math problems, track progress, and learn at your own pace with AI tutoring.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition">
            <CardHeader>
              <Camera className="w-12 h-12 text-purple-600 mb-4" />
              <CardTitle>Product Scanner</CardTitle>
              <CardDescription>Scan and compare product prices</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Take a photo of any product and get instant price estimates from multiple online marketplaces.
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Additional Features */}
        <div className="grid md:grid-cols-2 gap-8">
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <Zap className="w-12 h-12 text-yellow-600 mb-4" />
              <CardTitle>AI Chat Assistant</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Get instant help with math problems, product recommendations, and study questions powered by advanced AI.
              </p>
              <Link href="/learning">
                <Button variant="outline" size="sm">Try Now</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <TrendingUp className="w-12 h-12 text-red-600 mb-4" />
              <CardTitle>Smart Recommendations</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">
                Discover courses and products tailored to your learning progress and interests.
              </p>
              {isAuthenticated && (
                <Link href="/buyer/dashboard">
                  <Button variant="outline" size="sm">View Recommendations</Button>
                </Link>
              )}
            </CardContent>
          </Card>
        </div>

        {/* CTA Section */}
        <div className="mt-20 bg-blue-600 text-white rounded-lg p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Get Started?</h2>
          <p className="text-lg mb-8 opacity-90">
            Join thousands of learners and sellers on MarketLearn
          </p>
          {!isAuthenticated && (
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                Sign Up Now
              </Button>
            </a>
          )}
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 mt-20 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-bold text-white mb-4">Platform</h3>
              <ul className="space-y-2 text-sm">
                <li><Link href="/marketplace"><span className="hover:text-white">Marketplace</span></Link></li>
                <li><Link href="/learning"><span className="hover:text-white">Learning</span></Link></li>
                <li><Link href="/scanner"><span className="hover:text-white">Scanner</span></Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-white mb-4">For Sellers</h3>
              <ul className="space-y-2 text-sm">
                <li><Link href="/seller/dashboard"><span className="hover:text-white">Dashboard</span></Link></li>
                <li><span className="hover:text-white cursor-pointer">Upload Products</span></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-white mb-4">Support</h3>
              <ul className="space-y-2 text-sm">
                <li><span className="hover:text-white cursor-pointer">Help Center</span></li>
                <li><span className="hover:text-white cursor-pointer">Contact Us</span></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold text-white mb-4">Legal</h3>
              <ul className="space-y-2 text-sm">
                <li><span className="hover:text-white cursor-pointer">Privacy</span></li>
                <li><span className="hover:text-white cursor-pointer">Terms</span></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm">
            <p>&copy; 2026 MarketLearn. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
