import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, BookOpen } from "lucide-react";

export default function BuyerDashboard() {
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">My Dashboard</h1>

        <div className="grid md:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="w-5 h-5" />
                Purchased Products
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Your purchased digital products</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                Learning Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Your learning achievements and progress</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
