import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { Zap } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function BotDeployment() {
  const [botName, setBotName] = useState("");
  const [description, setDescription] = useState("");
  const [requirements, setRequirements] = useState("");

  const submitMutation = trpc.botDeployment.submitRequest.useMutation({
    onSuccess: () => {
      toast.success("Bot deployment request submitted successfully!");
      setBotName("");
      setDescription("");
      setRequirements("");
    },
    onError: (error) => {
      toast.error("Failed to submit request: " + error.message);
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!botName || !description) {
      toast.error("Please fill in all required fields");
      return;
    }

    submitMutation.mutate({
      botName,
      description,
      requirements: requirements ? JSON.parse(requirements) : undefined,
    } as any);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-2">
            <Zap className="w-8 h-8" />
            Bot Deployment Request
          </h1>
          <p className="text-gray-600">Request deployment of a custom bot for your needs</p>
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Card>
          <CardHeader>
            <CardTitle>Submit Deployment Request</CardTitle>
            <CardDescription>Fill in the details below to request bot deployment</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Bot Name *
                </label>
                <Input
                  placeholder="e.g., Customer Support Bot"
                  value={botName}
                  onChange={(e) => setBotName(e.target.value)}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Description *
                </label>
                <Textarea
                  placeholder="Describe what your bot should do..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={5}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Requirements (JSON)
                </label>
                <Textarea
                  placeholder='{"feature1": "value1", "feature2": "value2"}'
                  value={requirements}
                  onChange={(e) => setRequirements(e.target.value)}
                  rows={4}
                />
              </div>

              <Button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={submitMutation.isPending}
              >
                {submitMutation.isPending ? "Submitting..." : "Submit Request"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
